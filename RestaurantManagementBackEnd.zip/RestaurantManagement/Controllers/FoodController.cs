﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestaurantManagement.Features.Commands.Food;
using RestaurantManagement.Features.Queries.Food;
using RestaurantManagement.Models.Responses;

namespace RestaurantManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FoodController : ControllerBase
    {

        private readonly IMediator _mediator;

        public FoodController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        [Route("/GetFood")]
        public async Task<GetFoodByType> GetFoodByType([FromQuery]GetFoofByTypeRequest request)
        {
            return await _mediator.Send(request);
        }

        [HttpPost]
        [Route("/AddFood")]
        public async Task<bool> AddFood([FromBody] AddFoodRequest request)
        {
            return await _mediator.Send(request);
        }
    }
}
