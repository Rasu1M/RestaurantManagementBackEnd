﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestaurantManagement.Features.Commands.Receipt;
using RestaurantManagement.Features.Queries.Food;
using RestaurantManagement.Features.Queries.Receipt;
using RestaurantManagement.Models.Responses;

namespace RestaurantManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReceiptController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ReceiptController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        [Route("/AddReceipt")]
        public async Task<bool> AddReceipt([FromQuery] AddReceiptRequest request)
        {
            return await _mediator.Send(request);
        }

        [HttpGet]
        [Route("/GetReceipts")]
        public async Task<GetReceiptsResponse> GetReceipts([FromQuery] GetReceiptRequest request)
        {
            return await _mediator.Send(request);
        }
    }
}
