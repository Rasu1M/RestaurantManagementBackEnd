﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RestaurantManagement.Features.Commands.User.Create;
using RestaurantManagement.Features.Commands.User.Update.UpdatePassWord;
using RestaurantManagement.Features.Queries.User.LogIn;
using RestaurantManagement.Models.Responses;

namespace RestaurantManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountManagementController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AccountManagementController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        [Route("/LogIn")]
        public async Task<IActionResult> LogIn([FromBody] LogInRequest request)
        {
            
            var response = await _mediator.Send<LogInResponse>(request);

           return Ok(response);
        }

        [HttpPost]
        [Route("/SignUp")]
        public async Task<IActionResult> SignUp([FromBody] CreateUserRequest request)
        {

            var response = await _mediator.Send<Guid>(request);

            return Ok(response);
        }


        [HttpPost]
        [Route("/ChangePassWord")]
        public async Task<IActionResult> ChangePassword([FromBody] UpdatePassWordRequest request)
        {
            var response = await _mediator.Send<bool>(request);

            return Ok(response);

        }


    }
}
