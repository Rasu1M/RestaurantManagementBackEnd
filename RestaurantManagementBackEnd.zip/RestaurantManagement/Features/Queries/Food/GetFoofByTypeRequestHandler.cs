﻿using MediatR;
using RestaurantManagement.Models.DTOs;
using RestaurantManagement.Models.Responses;
using RestaurantManagement.Services.Interfaces.IGenericRepositories;

namespace RestaurantManagement.Features.Queries.Food
{
    public class GetFoofByTypeRequestHandler : IRequestHandler<GetFoofByTypeRequest, GetFoodByType>
    {
        private readonly IReadGenericRepository<Models.Domain.Food> _readRepository;

        public GetFoofByTypeRequestHandler(IReadGenericRepository<Models.Domain.Food> readRepository)
        {
            _readRepository = readRepository;
        }

        public  async Task<GetFoodByType> Handle(GetFoofByTypeRequest request, CancellationToken cancellationToken)
        {
            var foods = (await _readRepository.GetAllAsync(x => x.Type == request.foodType)).ToList();

            var response = new GetFoodByType();

            foreach (var food in foods)
            {
                var newfood = new FoodDTO()
                {
                    Name = food.Name,
                    Description = food.Description,
                    Cost = food.Cost,
                    Type = food.Type,
                };

                response.Foods.Add(newfood);
            }

            return response;

        }
    }
}
