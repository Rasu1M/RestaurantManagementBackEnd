﻿using MediatR;
using RestaurantManagement.Models.DTOs;
using RestaurantManagement.Models.Enums;
using RestaurantManagement.Models.Responses;

namespace RestaurantManagement.Features.Queries.Food
{
    public class GetFoofByTypeRequest : IRequest<GetFoodByType>
    {
        public FoodType foodType {  get; set; }
    }
}
