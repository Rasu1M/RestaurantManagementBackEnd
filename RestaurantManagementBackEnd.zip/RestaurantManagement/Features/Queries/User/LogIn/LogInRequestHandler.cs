﻿
using MediatR;
using Microsoft.AspNetCore.Identity.Data;
using MindMaze.Infrastructure.infrastructure.Repositories;
using RestaurantManagement.Models.Domain;
using RestaurantManagement.Models.Responses;
using RestaurantManagement.Services.Interfaces.IGenericRepositories;

namespace RestaurantManagement.Features.Queries.User.LogIn
{
    public class LogInRequestHandler : IRequestHandler<LogInRequest, LogInResponse>
    {
        private readonly IReadGenericRepository<Users> _readRepository;

        public LogInRequestHandler(IReadGenericRepository<Users> readRepository)
        {
            _readRepository = readRepository;
        }

        public async Task<LogInResponse> Handle(LogInRequest request, CancellationToken cancellationToken)
        {
            var User = await _readRepository.Getasync(x => x.Email == request.Email);

            if (User == null)
            {
                return new LogInResponse();
            }

            if (User.IsDeleted)
            {
                return new LogInResponse();
            }

            if (User.Password != request.PassWord) return new LogInResponse();

            return new LogInResponse()
            {
                UserID = User.ID,
                Name = User.Name,
                SurName = User.SurName,
                Email = User.Email,
            };

        }
    }
}
