﻿using MediatR;
using RestaurantManagement.Models.Responses;

namespace RestaurantManagement.Features.Queries.User.LogIn
{
    public class LogInRequest : IRequest<LogInResponse>
    {
        public string Email { get; set; }

        public string PassWord { get; set; }
    }
}
