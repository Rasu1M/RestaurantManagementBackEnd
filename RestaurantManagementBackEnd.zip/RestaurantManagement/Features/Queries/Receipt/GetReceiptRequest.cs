﻿using MediatR;
using RestaurantManagement.Models.Enums;
using RestaurantManagement.Models.Responses;

namespace RestaurantManagement.Features.Queries.Receipt
{
    public class GetReceiptRequest :IRequest<GetReceiptsResponse>
    {
        public Guid UserID { get; set; }

        public OrderStatus Status { get; set; }

    }
}
