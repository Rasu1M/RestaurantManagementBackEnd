﻿using MediatR;
using RestaurantManagement.Models.DTOs;
using RestaurantManagement.Models.Responses;
using RestaurantManagement.Services.Interfaces.IGenericRepositories;

namespace RestaurantManagement.Features.Queries.Receipt
{
    public class GetReceiptRequestHandler : IRequestHandler<GetReceiptRequest, GetReceiptsResponse>
    {

        private readonly IReadGenericRepository<Models.Domain.Receipt> _readRepository;

        public GetReceiptRequestHandler(IReadGenericRepository<Models.Domain.Receipt> readRepository)
        {
            _readRepository = readRepository;
        }
        public async Task<GetReceiptsResponse> Handle(GetReceiptRequest request, CancellationToken cancellationToken)
        {
            IEnumerable<Models.Domain.Receipt> receipts;

            var response = new GetReceiptsResponse();

            if (request.Status == Models.Enums.OrderStatus.All){

                receipts = await _readRepository.GetAllAsync(x => x.UserID == request.UserID);

            }

            else
            {
                receipts = await _readRepository.GetAllAsync(x => x.UserID == request.UserID && x.Status == request.Status);
            }

            receipts.ToList();

            foreach (var receipt in receipts)
            {

                var newReceipt = new ReceiptDTO()
                {
                    UserID = receipt.UserID,
                    Cost = receipt.Cost,
                    Status = receipt.Status
                };

                response.Receipts.Add(newReceipt);
            }

            return response;
        }
    }
}
