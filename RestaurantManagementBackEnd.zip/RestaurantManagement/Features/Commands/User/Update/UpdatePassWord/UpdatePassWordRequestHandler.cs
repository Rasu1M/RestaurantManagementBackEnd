﻿using MediatR;
using RestaurantManagement.Models.Domain;
using RestaurantManagement.Services.Interfaces;
using RestaurantManagement.Services.Interfaces.IGenericRepositories;

namespace RestaurantManagement.Features.Commands.User.Update.UpdatePassWord
{
    public class UpdatePassWordRequestHandler : IRequestHandler<UpdatePassWordRequest, bool>
    {
        private readonly IGenericRepository<Users> _genericRepository;
        private readonly IUnitOfWork _unitOfWork;

        public UpdatePassWordRequestHandler(IGenericRepository<Users> genericRepository, IUnitOfWork unitOfWork)
        {
            _genericRepository = genericRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(UpdatePassWordRequest request, CancellationToken cancellationToken)
        {
            

            var user = await _genericRepository.Getasync(x => x.ID == request.UserID);

            if (user == null)
            {
                return false;
            }

            user.Password = request.NewPassWord;

            _genericRepository.UpdateEntity(user);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;

        }
    }
}
