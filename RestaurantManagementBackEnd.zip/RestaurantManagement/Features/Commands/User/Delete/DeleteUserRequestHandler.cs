﻿using MediatR;
using RestaurantManagement.Models.Domain;
using RestaurantManagement.Services.Interfaces.IGenericRepositories;
using RestaurantManagement.Services.Interfaces;

namespace RestaurantManagement.Features.Commands.User.Delete
{
    public class DeleteUserRequestHandler : IRequestHandler<DeleteUserRequest, bool>
    {
        private readonly IWriteGenericRepository<Users> _writeRepository;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteUserRequestHandler(IWriteGenericRepository<Users> writeRepository, IUnitOfWork unitOfWork)
        {
            _writeRepository = writeRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(DeleteUserRequest request, CancellationToken cancellationToken)
        {
            _writeRepository.DeletebyID(request.UserID);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;

        }
    }
}
