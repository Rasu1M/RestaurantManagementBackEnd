﻿using MediatR;
using RestaurantManagement.Models.Domain;
using RestaurantManagement.Services.Interfaces;
using RestaurantManagement.Services.Interfaces.IGenericRepositories;

namespace RestaurantManagement.Features.Commands.Food
{
    public class AddFoodRequestHandler : IRequestHandler<AddFoodRequest, bool>
    {
        private readonly IWriteGenericRepository<Models.Domain.Food> _writeRepository;
        private readonly IUnitOfWork _unitOfWork;

        public AddFoodRequestHandler(IWriteGenericRepository<Models.Domain.Food> writeRepository,
                                     IUnitOfWork unitOfWork)
        {
            _writeRepository = writeRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(AddFoodRequest request, CancellationToken cancellationToken)
        {
            var food = new Models.Domain.Food()
            {
                Name = request.Name,
                Description = request.Description,
                Cost = request.Cost,
                Type = request.Type
            };

            await _writeRepository.Addasync(food);

            if((await _unitOfWork.SaveChangesAsync()) == 1)
            {
                return true;
            }

            return false;
        }
    }
}
