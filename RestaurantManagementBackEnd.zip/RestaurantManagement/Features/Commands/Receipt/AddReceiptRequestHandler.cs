﻿using MediatR;
using RestaurantManagement.Models.Domain;
using RestaurantManagement.Services.Interfaces;
using RestaurantManagement.Services.Interfaces.IGenericRepositories;

namespace RestaurantManagement.Features.Commands.Receipt
{
    public class AddReceiptRequestHandler : IRequestHandler<AddReceiptRequest, bool>
    {
        private readonly IWriteGenericRepository<Models.Domain.Receipt> _writeRepository;
        private readonly IUnitOfWork _unitOfWork;

        public AddReceiptRequestHandler(IWriteGenericRepository<Models.Domain.Receipt> writeRepository,
                                        IUnitOfWork unitOfWork)
        {
            _writeRepository = writeRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(AddReceiptRequest request, CancellationToken cancellationToken)
        {
            if(request.UserID == Guid.Empty) return false;

            var receipt = new Models.Domain.Receipt()
            {
                UserID = request.UserID,
                Cost = request.Cost,
                Status = Models.Enums.OrderStatus.accepted
            };

            _writeRepository.Add(receipt);

            if((await _unitOfWork.SaveChangesAsync()) == 1)
            {
                return true;
            }

            return false;
        }
    }
}
