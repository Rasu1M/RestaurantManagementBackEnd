﻿using MediatR;

namespace RestaurantManagement.Features.Commands.Receipt
{
    public class AddReceiptRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }

        public float Cost { get; set; }
    }
}
