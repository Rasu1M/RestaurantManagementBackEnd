﻿namespace RestaurantManagement.Models.Enums
{
    public enum OrderStatus
    {
        declined = 0,
        accepted = 1,
        sent = 2,
        completed = 3,
        All = 4
    }
}
