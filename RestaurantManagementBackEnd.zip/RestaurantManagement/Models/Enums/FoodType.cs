﻿namespace RestaurantManagement.Models.Enums
{
    public enum FoodType
    {
        Menu = 0,
        Food = 1,
        Drink = 2
    }
}
