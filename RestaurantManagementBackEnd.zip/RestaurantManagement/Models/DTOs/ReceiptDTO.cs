﻿using RestaurantManagement.Models.Enums;

namespace RestaurantManagement.Models.DTOs
{
    public class ReceiptDTO
    {
        public Guid UserID { get; set; }

        public OrderStatus Status { get; set; }

        public float Cost { get; set; }
    }
}
