﻿using RestaurantManagement.Models.Enums;

namespace RestaurantManagement.Models.Domain
{
    public class Food : BaseClass
    {
        public string Name { get; set; }

        public string Description { get; set; }

        public float Cost { get; set; }

        public FoodType Type { get; set; }
    }
}
