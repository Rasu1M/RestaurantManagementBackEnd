﻿using RestaurantManagement.Models.Enums;

namespace RestaurantManagement.Models.Domain
{
    public class Receipt : BaseClass
    {
        public Guid UserID { get; set; }

        public OrderStatus Status { get; set; }

        public float Cost { get; set; }

    }
}
