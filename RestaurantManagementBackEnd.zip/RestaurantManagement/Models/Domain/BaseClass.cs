﻿namespace RestaurantManagement.Models.Domain
{
    public abstract class BaseClass
    {
        public Guid ID { get; set; }

        public DateTime Created_Date { get; set; }

    }
}
