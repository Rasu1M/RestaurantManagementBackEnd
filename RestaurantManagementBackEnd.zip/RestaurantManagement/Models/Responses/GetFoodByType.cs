﻿using RestaurantManagement.Models.DTOs;

namespace RestaurantManagement.Models.Responses
{
    public class GetFoodByType
    {
        public List<FoodDTO> Foods { get; set; } = new List<FoodDTO>();
    }
}
