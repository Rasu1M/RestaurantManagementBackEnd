﻿using RestaurantManagement.Models.DTOs;

namespace RestaurantManagement.Models.Responses
{
    public class GetReceiptsResponse
    {
        public List<ReceiptDTO> Receipts { get; set; } = new List<ReceiptDTO>();
    }
}
