﻿namespace RestaurantManagement.Models.Responses
{
    public class LogInResponse
    {
        public Guid UserID { get; set; } = Guid.Empty;

        public string Name { get; set; }

        public string SurName { get; set; }

        public string Email { get; set; }

    }
}
