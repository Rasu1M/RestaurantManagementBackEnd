﻿using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Models.Domain;

namespace RestaurantManagement.DataBase.Interceptors
{
    public class CustomDatabaseModifyInterceptor : SaveChangesInterceptor
    {
        public override InterceptionResult<int> SavingChanges(DbContextEventData eventData, InterceptionResult<int> result)
        {
            var entities = eventData.Context.ChangeTracker.Entries().Where(entry => entry.State == EntityState.Added).Select(entry => (BaseClass)(entry.Entity)).ToList();

            foreach (var entity in entities)
            {
                if (entity.ID == Guid.Empty)
                    entity.ID = Guid.NewGuid();
                entity.Created_Date = DateTime.UtcNow;
            }

            return base.SavingChanges(eventData, result);
        }

        public override ValueTask<InterceptionResult<int>> SavingChangesAsync(DbContextEventData eventData, InterceptionResult<int> result, CancellationToken cancellationToken = default)
        {
            var entities = eventData.Context.ChangeTracker.Entries().Where(entry => entry.State == EntityState.Added).Select(entry => (BaseClass)(entry.Entity)).ToList();

            foreach (var entity in entities)
            {
                if (entity.ID == Guid.Empty)
                    entity.ID = Guid.NewGuid();
                entity.Created_Date = DateTime.UtcNow;
            }
            return base.SavingChangesAsync(eventData, result, cancellationToken);
        }
    }

}