﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RestaurantManagement.Models.Domain;

namespace RestaurantManagement.DataBase.Configurations
{
    public class UserConfiguration : BaseConfiguration<Users>
    {
        public override void Configure(EntityTypeBuilder<Users> builder)
        {
            base.Configure(builder);

            builder.ToTable(nameof(Users));

        }
    }
}
