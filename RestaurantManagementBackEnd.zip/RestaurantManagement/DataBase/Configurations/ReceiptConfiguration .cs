﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RestaurantManagement.Models.Domain;

namespace RestaurantManagement.DataBase.Configurations
{
    public class ReceiptConfiguration : BaseConfiguration<Receipt>
    {
        public override void Configure(EntityTypeBuilder<Receipt> builder)
        {
            base.Configure(builder);

            builder.ToTable(nameof(Receipt));

        }
    }
}
