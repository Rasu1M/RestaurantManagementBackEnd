﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Models.Domain;

namespace RestaurantManagement.DataBase.Configurations
{
    public class BaseConfiguration<Tentity> : IEntityTypeConfiguration<Tentity> where Tentity : BaseClass
    {
        public virtual void Configure(EntityTypeBuilder<Tentity> builder)
        {
            builder.HasKey(x => x.ID);
        }
    }
}