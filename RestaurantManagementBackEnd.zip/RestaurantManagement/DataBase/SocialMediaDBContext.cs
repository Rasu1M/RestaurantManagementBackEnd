﻿using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Models.Domain;
using System.Reflection;

namespace RestaurantManagement.DataBase
{
    public class SocialMediaDBContext : DbContext
    {


        public SocialMediaDBContext()
        {

        }

        public SocialMediaDBContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Users> User { get; set; }

        public DbSet<Food> Food { get; set; } 

        public DbSet<Receipt> Receipt { get; set; }



    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

                var connecstr = "Data Source=RASUL\\SQLEXPRESS;Initial Catalog=RestaurantManagement;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

                optionsBuilder.UseSqlServer(connecstr, op =>
                {
                    op.EnableRetryOnFailure();
                    op.CommandTimeout(100);
                });
            }
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}