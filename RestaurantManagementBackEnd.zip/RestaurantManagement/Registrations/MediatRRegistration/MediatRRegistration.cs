﻿using RestaurantManagement.Features.Queries.User.LogIn;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace RestaurantManagement.Registrations.MediatRRegistration
{
    public static class MediatRRegistration
    {
        public static IServiceCollection RegisterToMediatR(this IServiceCollection Services)
        {

            Services.AddMediatR(conf =>
            {
                conf.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly());
            });

            return Services;
        }
    }
}
