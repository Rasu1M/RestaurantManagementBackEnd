﻿using Microsoft.EntityFrameworkCore;
using MindMaze.Infrastructure.infrastructure.Repositories;
using MindMaze.Infrastructure.infrastructure.Services;
using RestaurantManagement.Services.Interfaces.IGenericRepositories;
using RestaurantManagement.Services.Interfaces;
using RestaurantManagement.DataBase.Interceptors;
using RestaurantManagement.DataBase;

namespace RestaurantManagement.Registrations.DatabaseRegistration
{
    public static class DatabaseRegistration
    {

        public static IServiceCollection RegisterToDatabase(this IServiceCollection Services, IConfiguration configuration)
        {


            Services.AddDbContext<SocialMediaDBContext>(sp =>
            {

                var connstr = configuration["ConnectionStrings:RestaurantManagementSQl"];
                

                sp.UseSqlServer(connstr, op =>
                {
                    op.EnableRetryOnFailure();
                    op.CommandTimeout(100);
                });

                sp.AddInterceptors(new CustomDatabaseModifyInterceptor());

                sp.EnableDetailedErrors(true);
                //TODO change this after
                sp.EnableSensitiveDataLogging(true);
            });

            // Services.AddScoped<DbContext, SocialMediaDBContext>();

            Services.AddTransient(typeof(IReadGenericRepository<>), typeof(ReadRepository<>));

            Services.AddTransient(typeof(IWriteGenericRepository<>), typeof(WriteRepository<>));

            Services.AddTransient(typeof(IGenericRepository<>), typeof(GenericRepository<>));

            Services.AddTransient<IUnitOfWork, UnitOfWork>();






            return Services;
        }
    }
}